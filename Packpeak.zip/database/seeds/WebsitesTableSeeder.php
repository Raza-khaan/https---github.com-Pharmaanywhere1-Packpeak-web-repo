<?php

use Illuminate\Database\Seeder;
use App\Websites;

class WebsitesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $ob = [
        //     [
        //         'id'             => 1,
        //         'uuid'           =>'superadmin',
                
        //     ],
        // ];

        // Websites::insert($ob);
    }
}
