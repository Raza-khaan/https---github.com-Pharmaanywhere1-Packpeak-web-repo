<?php

use Illuminate\Database\Seeder;
use App\Phermacists;

class PhermacistsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $ob = [
        //     [
        //         'id'             => null,
        //         'username'       =>'superadmin',
        //         'first_name'     =>'super',
        //         'last_name'      =>'Admin',
        //         'email'          =>'super@gmail.in',
        //         'company_name'   =>'superAdmin',
        //         'host_name'      =>'superadmin',
        //         'password'       =>'$2y$10$40enDFKxi7XV9oN.8Tsof.1WaMkqdzKURD9/3hDHv4J/TI0HUjKeu',
        //         'subscription'   =>1,

        //     ],
        // ];

        // Phermacists::insert($ob);
    }
}
