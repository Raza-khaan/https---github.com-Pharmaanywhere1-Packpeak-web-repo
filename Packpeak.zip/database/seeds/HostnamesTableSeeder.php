<?php

use Illuminate\Database\Seeder;
use App\Hostnames;

class HostnamesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $ob = [
        //     [
        //         'id'             => null,
        //         'fqdn'           =>'superadmin.localhost',
        //         'website_id'     =>1,
                
        //     ],
        // ];

        // Hostnames::insert($ob);
    }
}
